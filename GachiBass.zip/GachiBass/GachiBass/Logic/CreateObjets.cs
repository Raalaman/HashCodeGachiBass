﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GachiBass.Logic
{
    class CreateObjets
    {
        public static void Create()
        {

        }
    }
}
