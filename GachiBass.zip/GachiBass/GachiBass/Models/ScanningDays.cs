﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GachiBass.Models
{
    public class ScanningDays
    {
        public int Days { get; set; }
    }
}
