﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GachiBass.Models
{
    public class Book
    {
        public string Id { get;  set; }
        //Descrito?
        public decimal Score { get; set; }
        public bool Scanned { get; set; }

    }
}
